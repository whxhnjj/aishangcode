


Page({

  data: {
  
  },

  onLoad: function (e) {
    let that = this;
    that.setData({
      pro_id : e.pro_id
    })
  },

  onShareAppMessage: function () {
  
  }
})