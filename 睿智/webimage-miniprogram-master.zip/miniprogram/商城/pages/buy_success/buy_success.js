


Page({

  data: {
  
  },

 
  onLoad: function (e) {
    let that = this;
    that.setData({
      id : e.id,
      price : e.price
    })
  },

 
  onShareAppMessage: function () {
  
  }
})