export default [
    {
    src:'http://www.oncemeet.com/music/93millionmiles.mp3',
    poster: 'http://www.hsbggb.com/yinyue/yinyue.jpg',
    name:'生日快乐',
    author: ''
    },
    {
      src: 'http://www.oncemeet.com/music/93millionmiles.mp3',
    poster: 'http://www.hsbggb.com/yinyue/yinyue.jpg',
    name: '生日快乐',
    author: ''
    },
    {
      src: 'http://www.oncemeet.com/music/93millionmiles.mp3',
      poster: 'http://www.hsbggb.com/yinyue/yinyue.jpg',
      name: '生日快乐',
      author: ''
    },
    {
      src: 'http://www.oncemeet.com/music/93millionmiles.mp3',
      poster: 'http://www.hsbggb.com/yinyue/yinyue.jpg',
      name: '生日快乐',
      author: ''
    },
]