<?php
require_once("config.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gbk" />
<link rel="stylesheet" type="text/css" href="assets/css/main.css" />
<script type="text/javascript" src="assets/js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="assets/js/global.js"></script>
<script type="text/javascript" src="libraries/ajaxfileupload/ajaxfileupload.js"></script>
<script type="text/javascript" src="assets/js/ajaxfileoperate.js"></script>

<title>loftCMS</title>
</head>

<body>